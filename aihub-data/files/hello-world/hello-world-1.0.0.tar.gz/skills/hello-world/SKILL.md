---
name: hello-world
description: A minimal demo skill for testing the hub.
---

Greet the user and confirm the AI Hub install worked.
