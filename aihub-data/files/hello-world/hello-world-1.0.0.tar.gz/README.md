# hello-world

A minimal demo skill for testing the hub.

## Usage

Ask Claude to use the **hello-world** skill.

- Installs with `aihub install hello-world`
- Fully reversible with `aihub uninstall hello-world`
