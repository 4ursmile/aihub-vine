# pdf-summarizer

Summarizes long PDF documents into key points.

## Usage

Ask Claude to use the **pdf-summarizer** skill.

- Installs with `aihub install pdf-summarizer`
- Fully reversible with `aihub uninstall pdf-summarizer`
