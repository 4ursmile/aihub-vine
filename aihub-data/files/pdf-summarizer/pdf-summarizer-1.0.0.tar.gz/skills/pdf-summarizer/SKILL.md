---
name: pdf-summarizer
description: Summarizes long PDF documents into key points.
---

Read the PDF, extract headings, and produce a bullet summary with page references.
