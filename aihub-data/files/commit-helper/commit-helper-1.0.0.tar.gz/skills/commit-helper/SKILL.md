---
name: commit-helper
description: Writes clear conventional commit messages from staged changes.
---

Inspect staged changes and write a conventional commit message with a short subject and a body.
