# commit-helper

Writes clear conventional commit messages from staged changes.

## Usage

Ask Claude to use the **commit-helper** skill.

- Installs with `aihub install commit-helper`
- Fully reversible with `aihub uninstall commit-helper`
