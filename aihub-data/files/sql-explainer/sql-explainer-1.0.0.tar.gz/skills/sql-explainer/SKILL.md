---
name: sql-explainer
description: Explains SQL queries and suggests index improvements.
---

Explain what the query does step by step, then suggest indexes and rewrites.
