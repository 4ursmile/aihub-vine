# sql-explainer

Explains SQL queries and suggests index improvements.

## Usage

Ask Claude to use the **sql-explainer** skill.

- Installs with `aihub install sql-explainer`
- Fully reversible with `aihub uninstall sql-explainer`
