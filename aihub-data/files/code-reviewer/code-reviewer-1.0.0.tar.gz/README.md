# code-reviewer

Reviews diffs for bugs, style and missing tests.

## Usage

Ask Claude to use the **code-reviewer** skill.

- Installs with `aihub install code-reviewer`
- Fully reversible with `aihub uninstall code-reviewer`
